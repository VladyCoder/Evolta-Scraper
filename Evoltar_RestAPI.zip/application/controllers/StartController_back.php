<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StartController extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$evolta_config = $this->config->item('evolta');
		$this->evolta_host = $evolta_config['EVOLTA_HOST'];
		$this->evolta_username = $evolta_config['EVOLTA_USERNAME'];
		$this->evolta_password = $evolta_config['EVOLTA_PASSWORD'];
		$this->load_max_count = 1;

		$this->load->dbforge();
		$this->load->database();
		$this->load->helper('client');

		$this->load->model('ProjectModel');
		$this->load->model('UserModel');
		$this->load->model('PropertyModel');
		$this->load->model('AccountModel');
	}

	public function index()
	{
		$this->cleanDB();

		// $this->ProjectModel->projects($this);
		// $this->ProjectModel->projectDetail($this);
		// $this->ProjectModel->etapaDetail($this);
		// $this->ProjectModel->edificioDetail($this);

		// $this->UserModel->clients($this);
		// $this->UserModel->users($this);
		// $this->UserModel->userDetail($this);

		// $this->PropertyModel->unitProperty($this);
		// $this->PropertyModel->modelProperty($this);
		// $this->PropertyModel->operationComercial($this);
		// $this->PropertyModel->stock($this);

		// $this->AccountModel->contact($this);
		// $this->AccountModel->prospecto($this);  //error
		// $this->AccountModel->payment($this);
		$this->AccountModel->accountStatus($this);  //error
		// $this->AccountModel->reportAnalisis($this);

		// echo "finishedeee ..... ";
		return 'adfsf';
	}


	private function cleanDB()
	{
		$this->dbforge->drop_table('proyecto',TRUE);
		$this->dbforge->drop_table('proyecto_detalle',TRUE);
		$this->dbforge->drop_table('etapa_detalle',TRUE);
		$this->dbforge->drop_table('edificio_detalle',TRUE);

		$this->dbforge->drop_table('cliente',TRUE);
		$this->dbforge->drop_table('usuario',TRUE);
		$this->dbforge->drop_table('usuario_detalle',TRUE);

		$this->dbforge->drop_table('unidad_inmueble',TRUE);
		$this->dbforge->drop_table('model_inmueble',TRUE);
		$this->dbforge->drop_table('operacion_comercial',TRUE);
		$this->dbforge->drop_table('stocks',TRUE);

		$this->dbforge->drop_table('contacto',TRUE);
		$this->dbforge->drop_table('prospecto',TRUE);
		$this->dbforge->drop_table('pago',TRUE);
		$this->dbforge->drop_table('cuentas',TRUE);
		$this->dbforge->drop_table('reporte_analisis',TRUE);
	}

	public function getToken()
	{
		try {
			$params = [
				'username' => $this->evolta_username,
				'password' => $this->evolta_password,
				'grant_type' => 'password'
			];
	
			$res = curl_request('POST', $this->evolta_host.'/oauth2/token', [
				'data' => $params
			]);
			
			return $res->access_token;

		} catch(Exeption $err) {
			throw $err;
		}
	}

	public function saveData($service, $result)
	{
		if(is_array($result)){
			// echo '********';
			// echo ceil(count($result)/$this->load_max_count);
			// echo '**********';
			for($i = 0; $i < ceil(count($result)/$this->load_max_count); $i++){
				$_result = array_splice($result, 0, $this->load_max_count);
				$data = flatten_request_data($_result);
				
				if($i == 0){
					// echo '//////';
					// echo json_encode($data);
					// echo '//////';
					$fields = generate_db_fields($data);
					$this->dbforge->add_field($fields);
					$this->dbforge->create_table($service, TRUE);
				}
				
				// echo '//////';
				// echo $i;
				// echo '**********';
				// echo json_encode($data);
				// echo '//////';
				$data = merge_array_key(array_keys($fields), $data);
				echo '**********';
				echo json_encode($data);
				$this->db->insert_batch($service, $data);
			}
		}else{
			$data = flatten_request_data($result);
			$fields = generate_db_fields($data);
			$default_row = key_array($fields);

			$this->dbforge->add_field($fields);
			$this->dbforge->create_table($service, TRUE);

			$data = array_merge($default_row, $data);
			$this->db->insert_batch($service, $data);
		}
	}

	public function log($service, $parameter, $value, $state)
	{
		$data = array(
			'servicio' => $service,
			'parametro' => $parameter,
			'valor' => $value,
			'fechaEjecucion' => date('d/m/Y'),
			'usuarioEjecucion' => 'SERVERNAME',
			'state' => $state
		);

		$this->db->insert('servicio_log', $data);
	}
}
